@echo off
cd /d "%~dp0"
title QuizShot ChatGPT v3.2.2 DEBUG
py quizshot_chatgpt.py
pause
