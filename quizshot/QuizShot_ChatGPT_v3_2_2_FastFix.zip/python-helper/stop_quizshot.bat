@echo off
taskkill /IM pythonw.exe /F >nul 2>&1
echo QuizShot background process stopped.
pause
