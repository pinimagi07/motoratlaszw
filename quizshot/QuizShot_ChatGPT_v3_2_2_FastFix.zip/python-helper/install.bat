@echo off
cd /d "%~dp0"
title QuizShot ChatGPT v3.2.2 - Install
echo Installing/updating dependencies...
py -m pip install -r requirements.txt
echo.
echo Finished.
pause
