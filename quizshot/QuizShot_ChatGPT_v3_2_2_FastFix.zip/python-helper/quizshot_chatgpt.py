import base64
import ctypes
from ctypes import wintypes
import hashlib
import io
import json
import os
import queue
import secrets
import threading
import time
import uuid
import webbrowser
import winsound
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs

import jwt
import pyperclip
import requests
from PIL import ImageGrab

APP_NAME = "QuizShot Helper"
RESOURCE = "https://api.openai.com/v1"
AUTH_URL = "https://auth.openai.com/api/accounts/authorize"
TOKEN_URL = "https://auth.openai.com/api/accounts/oauth/token"
OIDC_CONFIG = "https://auth.openai.com/.well-known/openid-configuration"
RESPONSES_URL = "https://api.openai.com/v1/responses"
MODELS_URL = "https://api.openai.com/v1/models"
SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"

LOCALAPPDATA = Path(os.environ.get("LOCALAPPDATA", Path.home()))
DATA_DIR = LOCALAPPDATA / "QuizShotGPT"
DATA_DIR.mkdir(parents=True, exist_ok=True)
HOST_FILE = DATA_DIR / "host.json"
CREDS_FILE = DATA_DIR / "credentials.json"
MODEL_CACHE_FILE = DATA_DIR / "model_cache.json"
LOG_FILE = DATA_DIR / "quizshot.log"

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "QuizShotGPT/3.2.2"})

auth_lock = threading.Lock()
solve_lock = threading.Lock()

# Load WinDLL with use_last_error=True so ctypes.get_last_error() is meaningful.
user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
try:
    dwmapi = ctypes.WinDLL("dwmapi", use_last_error=True)
except OSError:
    dwmapi = None

WH_KEYBOARD_LL = 13
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
VK_LWIN = 0x5B
VK_RWIN = 0x5C
VK_S = 0x53
LLKHF_INJECTED = 0x00000010
DWMWA_EXTENDED_FRAME_BOUNDS = 9

INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002

hook_handle = None
hook_proc_ref = None
win_held = False
win_vk = None
win_down_buffered = False
quiz_chord_active = False
selected_model = None


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class INPUTUNION(ctypes.Union):
    # Include every Windows INPUT variant so sizeof(INPUT) matches the native
    # x64 structure (40 bytes), even though QuizShot only sends keyboard input.
    _fields_ = [
        ("mi", MOUSEINPUT),
        ("ki", KEYBDINPUT),
        ("hi", HARDWAREINPUT),
    ]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [
        ("type", wintypes.DWORD),
        ("u", INPUTUNION),
    ]


# LPARAM/WPARAM/LRESULT are pointer-sized on 64-bit Windows.
LRESULT = ctypes.c_ssize_t
HHOOK = ctypes.c_void_p
HINSTANCE = ctypes.c_void_p

LowLevelKeyboardProc = ctypes.WINFUNCTYPE(
    LRESULT,
    ctypes.c_int,
    wintypes.WPARAM,
    wintypes.LPARAM,
)

# Declare all critical WinAPI signatures explicitly.
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = HINSTANCE

user32.SetWindowsHookExW.argtypes = [
    ctypes.c_int,
    LowLevelKeyboardProc,
    HINSTANCE,
    wintypes.DWORD,
]
user32.SetWindowsHookExW.restype = HHOOK

user32.UnhookWindowsHookEx.argtypes = [HHOOK]
user32.UnhookWindowsHookEx.restype = wintypes.BOOL

user32.CallNextHookEx.argtypes = [
    HHOOK,
    ctypes.c_int,
    wintypes.WPARAM,
    wintypes.LPARAM,
]
user32.CallNextHookEx.restype = LRESULT

user32.SendInput.argtypes = [
    wintypes.UINT,
    ctypes.POINTER(INPUT),
    ctypes.c_int,
]
user32.SendInput.restype = wintypes.UINT

user32.GetMessageW.argtypes = [
    ctypes.POINTER(wintypes.MSG),
    wintypes.HWND,
    wintypes.UINT,
    wintypes.UINT,
]
user32.GetMessageW.restype = wintypes.BOOL

user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.TranslateMessage.restype = wintypes.BOOL
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.restype = LRESULT

user32.GetForegroundWindow.argtypes = []
user32.GetForegroundWindow.restype = wintypes.HWND

user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
user32.GetWindowRect.restype = wintypes.BOOL


def log(message):
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{stamp}] {message}"
    try:
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    try:
        print(line, flush=True)
    except Exception:
        pass


def load_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, data):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def success_beep():
    try:
        winsound.Beep(1150, 80)
    except Exception:
        pass


def error_beep():
    try:
        winsound.Beep(470, 100)
        winsound.Beep(470, 100)
    except Exception:
        pass


def b64url_no_pad(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def get_host_id():
    obj = load_json(HOST_FILE, {}) or {}
    host_id = obj.get("ext_agent_host_id")
    if host_id:
        return host_id
    host_id = "urn:uuid:" + str(uuid.uuid4())
    save_json(HOST_FILE, {"ext_agent_host_id": host_id})
    return host_id


def show_continue_dialog():
    try:
        import tkinter as tk
        result = {"go": False}
        root = tk.Tk()
        root.title("QuizShot ChatGPT")
        root.geometry("430x225")
        root.resizable(False, False)
        frame = tk.Frame(root, padx=24, pady=22)
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Connect your ChatGPT plan",
                 font=("Segoe UI", 16, "bold")).pack(anchor="w")
        tk.Label(
            frame,
            text=("Sign in once to let this local QuizShot helper use eligible "
                  "requests from your ChatGPT plan. No API key is required."),
            font=("Segoe UI", 10),
            wraplength=375,
            justify="left",
        ).pack(anchor="w", pady=(10, 20))

        def go():
            result["go"] = True
            root.destroy()

        tk.Button(
            frame,
            text="Continue with ChatGPT",
            command=go,
            font=("Segoe UI", 11, "bold"),
            padx=18,
            pady=8,
        ).pack(anchor="w")

        root.protocol("WM_DELETE_WINDOW", root.destroy)
        root.mainloop()
        return result["go"]
    except Exception:
        ans = input("Press ENTER to Continue with ChatGPT, or Q to quit: ").strip().lower()
        return ans != "q"


class OAuthCallback:
    def __init__(self):
        self.q = queue.Queue(maxsize=1)
        self.server = None

    def start(self):
        q = self.q

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path != "/auth/callback":
                    self.send_response(404)
                    self.end_headers()
                    return
                params = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                try:
                    q.put_nowait(params)
                except queue.Full:
                    pass
                body = b"<html><body><h2>QuizShot connected</h2><p>You can close this tab.</p></body></html>"
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        port = self.server.server_address[1]
        self.redirect_uri = f"http://127.0.0.1:{port}/auth/callback"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return self.redirect_uri

    def wait(self, timeout=180):
        try:
            return self.q.get(timeout=timeout)
        finally:
            if self.server:
                self.server.shutdown()
                self.server.server_close()


def verify_id_token(id_token, client_id, nonce):
    cfg = SESSION.get(OIDC_CONFIG, timeout=10)
    cfg.raise_for_status()
    oidc = cfg.json()
    jwk_client = jwt.PyJWKClient(oidc["jwks_uri"])
    key = jwk_client.get_signing_key_from_jwt(id_token).key
    claims = jwt.decode(
        id_token,
        key,
        algorithms=["RS256", "ES256"],
        audience=client_id,
        issuer=oidc.get("issuer", "https://auth.openai.com"),
        options={"require": ["exp", "iss", "aud", "sub"]},
        leeway=45,
    )
    if claims.get("nonce") != nonce:
        raise RuntimeError("OpenAI sign-in returned an invalid nonce.")
    return claims


def oauth_sign_in(existing=None):
    with auth_lock:
        callback = OAuthCallback()
        redirect_uri = callback.start()
        state_value = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = b64url_no_pad(hashlib.sha256(verifier.encode("ascii")).digest())
        is_new = not existing or not existing.get("client_id")
        client_id = "dynamic_agent_client" if is_new else existing["client_id"]

        params = {
            "client_id": client_id,
            "ext_agent_host_id": get_host_id(),
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "scope": SCOPES,
            "resource": RESOURCE,
            "state": state_value,
            "nonce": nonce,
            "code_challenge_method": "S256",
            "code_challenge": challenge,
        }
        if is_new:
            params["agent_name_hint"] = APP_NAME
        elif existing.get("id_token"):
            params["id_token_hint"] = existing["id_token"]

        webbrowser.open(AUTH_URL + "?" + urlencode(params))
        data = callback.wait()

        if data.get("state") != state_value:
            raise RuntimeError("OpenAI sign-in state validation failed.")
        if data.get("error"):
            raise RuntimeError(data.get("error_description", data["error"]))

        code = data.get("code")
        if not code:
            raise RuntimeError("No authorization code returned.")

        exchange_client_id = data.get("client_id") if is_new else existing["client_id"]
        if not exchange_client_id:
            raise RuntimeError("No client ID returned.")

        r = SESSION.post(
            TOKEN_URL,
            data={
                "grant_type": "authorization_code",
                "client_id": exchange_client_id,
                "code": code,
                "code_verifier": verifier,
                "redirect_uri": redirect_uri,
                "resource": RESOURCE,
            },
            timeout=15,
        )
        if not r.ok:
            raise RuntimeError(f"Token exchange failed ({r.status_code}): {r.text}")

        td = r.json()
        claims = verify_id_token(td["id_token"], exchange_client_id, nonce)
        scopes = set((td.get("scope") or "").split())
        if "chatgpt.tokens.use.direct" not in scopes:
            raise RuntimeError("ChatGPT plan usage was not authorized.")

        creds = {
            "email": claims.get("email", ""),
            "client_id": exchange_client_id,
            "id_token": td["id_token"],
            "access_token": td["access_token"],
            "refresh_token": td.get("refresh_token", ""),
            "expires_in": td.get("expires_in", 3600),
            "saved_at": time.time(),
        }
        save_json(CREDS_FILE, creds)
        return creds


def token_needs_refresh(c):
    return time.time() >= float(c.get("saved_at", 0)) + int(c.get("expires_in", 3600)) - 300


def refresh_credentials(c):
    rt = c.get("refresh_token")
    if not rt:
        raise RuntimeError("No refresh token available.")

    r = SESSION.post(
        TOKEN_URL,
        data={
            "grant_type": "refresh_token",
            "client_id": c["client_id"],
            "refresh_token": rt,
            "resource": RESOURCE,
        },
        timeout=15,
    )
    if not r.ok:
        raise RuntimeError(f"Token refresh failed ({r.status_code}): {r.text}")

    td = r.json()
    c = dict(c)
    c.update({
        "access_token": td["access_token"],
        "refresh_token": td.get("refresh_token", rt),
        "id_token": td.get("id_token", c.get("id_token", "")),
        "expires_in": td.get("expires_in", 3600),
        "saved_at": time.time(),
    })
    save_json(CREDS_FILE, c)
    return c


def ensure_credentials():
    c = load_json(CREDS_FILE)
    if not c:
        if not show_continue_dialog():
            raise SystemExit("Sign-in cancelled.")
        return oauth_sign_in()
    if token_needs_refresh(c):
        try:
            c = refresh_credentials(c)
        except Exception:
            c = oauth_sign_in(c)
    return c


def model_score(m):
    t = (m.get("slug", "") + " " + m.get("name", "")).lower()
    score = 0
    if "gpt-6" in t and "luna" in t:
        score += 1000
    elif "luna" in t:
        score += 900
    if "instant" in t:
        score += 800
    if "fast" in t:
        score += 700
    if "gpt-6" in t:
        score += 250
    if "gpt-5.6" in t:
        score += 220
    if "sol" in t:
        score += 160
    if "astra" in t:
        score += 110
    for bad in ("audio", "realtime", "embedding", "moderation", "transcribe", "tts"):
        if bad in t:
            score -= 1000
    return score


def select_model(access_token):
    cache = load_json(MODEL_CACHE_FILE, {}) or {}
    if cache.get("slug") and time.time() - cache.get("saved_at", 0) < 7 * 86400:
        return cache["slug"]

    r = SESSION.get(MODELS_URL, headers={"Authorization": f"Bearer {access_token}"}, timeout=10)
    if not r.ok:
        raise RuntimeError(f"Could not list models ({r.status_code}): {r.text}")

    raw = r.json().get("models", r.json().get("data", []))
    models = []
    for x in raw:
        if isinstance(x, dict):
            slug = x.get("slug") or x.get("id")
            if slug and x.get("visibility") in (None, "list"):
                models.append({"slug": slug, "name": x.get("display_name", slug)})
    if not models:
        raise RuntimeError("No usable models returned.")

    models.sort(key=model_score, reverse=True)
    chosen = models[0]["slug"]
    save_json(MODEL_CACHE_FILE, {"slug": chosen, "saved_at": time.time()})
    return chosen


def get_foreground_rect():
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    rect = RECT()
    ok = False
    if dwmapi:
        try:
            result = dwmapi.DwmGetWindowAttribute(
                hwnd, DWMWA_EXTENDED_FRAME_BOUNDS,
                ctypes.byref(rect), ctypes.sizeof(rect)
            )
            ok = result == 0
        except Exception:
            pass
    if not ok and not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return None
    return (rect.left, rect.top, rect.right, rect.bottom)


def capture_active_window():
    rect = get_foreground_rect()
    if not rect:
        raise RuntimeError("Could not identify active window.")
    return ImageGrab.grab(bbox=rect, all_screens=True)


def encode_image(img):
    img = img.convert("RGB")
    max_side = 1200
    scale = min(1.0, max_side / max(img.width, img.height))
    if scale < 1.0:
        img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=72, optimize=False)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def prompt():
    return (
        "AI assistance is explicitly permitted. Solve the current visible quiz question. "
        "If it is single-answer multiple choice with A/B/C/D labels, return ONLY the correct "
        "letter. If multi-select, return ONLY the correct letters separated by commas. "
        "Otherwise return ONLY the shortest final answer/value with units if required. "
        "No explanation and no working. If unreadable, return ONLY NEED_CLEARER_VIEW."
    )


def parse_stream(r):
    chunks = []
    for raw in r.iter_lines():
        if not raw:
            continue
        line = raw.decode("utf-8", "replace").strip() if isinstance(raw, bytes) else str(raw).strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            continue
        et = event.get("type")
        if et == "response.output_text.delta":
            chunks.append(str(event.get("delta", "")))
        elif et == "response.failed":
            err = ((event.get("response") or {}).get("error") or {})
            raise RuntimeError(err.get("message", err.get("code", "request failed")))
        elif et == "response.incomplete":
            details = ((event.get("response") or {}).get("incomplete_details") or {})
            raise RuntimeError(
                "ChatGPT response incomplete: "
                + details.get("reason", "unknown reason")
            )
    answer = "".join(chunks).strip()
    if not answer:
        raise RuntimeError("ChatGPT returned no answer text.")
    return " ".join(answer.split())


def call_chatgpt(token, model, image_b64):
    body = {
        "model": model,
        "input": [{
            "role": "user",
            "content": [
                {"type": "input_text", "text": prompt()},
                {"type": "input_image",
                 "image_url": "data:image/jpeg;base64," + image_b64,
                 "detail": "auto"},
            ],
        }],
        "store": False,
        "stream": True,
        # Luna supports reasoning effort "none". This is the lowest-latency
        # setting and prevents hidden reasoning from consuming the response
        # budget before a visible A/B/C/D answer is emitted.
        "reasoning": {"effort": "none"},
        # Headroom matters because max_output_tokens also covers invisible
        # formatting/reasoning tokens. The prompt still demands a one-token
        # answer for normal multiple-choice questions.
        "max_output_tokens": 96,
    }
    r = SESSION.post(
        RESPONSES_URL,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        },
        json=body,
        stream=True,
        timeout=(2.5, 14.0),
    )
    if not r.ok:
        raise RuntimeError(f"ChatGPT HTTP {r.status_code}: {r.text}")
    return parse_stream(r)


def solve():
    global selected_model
    if not solve_lock.acquire(blocking=False):
        return
    started = time.perf_counter()
    try:
        img = capture_active_window()
        encoded = encode_image(img)
        creds = ensure_credentials()
        if token_needs_refresh(creds):
            creds = refresh_credentials(creds)
        if not selected_model:
            selected_model = select_model(creds["access_token"])
        answer = call_chatgpt(creds["access_token"], selected_model, encoded)
        pyperclip.copy(answer)
        elapsed = time.perf_counter() - started
        log(f"SUCCESS {elapsed:.2f}s model={selected_model} answer={answer!r}")
        success_beep()
    except Exception as e:
        log(f"ERROR: {e}")
        error_beep()
    finally:
        solve_lock.release()


def send_key(vk, keyup=False):
    flags = KEYEVENTF_KEYUP if keyup else 0
    inp = INPUT(
        type=INPUT_KEYBOARD,
        ki=KEYBDINPUT(wVk=vk, wScan=0, dwFlags=flags, time=0, dwExtraInfo=None),
    )
    sent = user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
    if sent != 1:
        log(f"SendInput failed last_error={ctypes.get_last_error()}")


def replay_win_down(vk):
    send_key(vk, False)


def replay_win_tap(vk):
    send_key(vk, False)
    send_key(vk, True)


def hook_callback(nCode, wParam, lParam):
    global win_held, win_vk, win_down_buffered, quiz_chord_active
    if nCode < 0:
        return user32.CallNextHookEx(hook_handle, nCode, wParam, lParam)

    data = ctypes.cast(lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents

    if data.flags & LLKHF_INJECTED:
        return user32.CallNextHookEx(hook_handle, nCode, wParam, lParam)

    vk = data.vkCode
    is_down = wParam in (WM_KEYDOWN, WM_SYSKEYDOWN)
    is_up = wParam in (WM_KEYUP, WM_SYSKEYUP)

    if vk in (VK_LWIN, VK_RWIN):
        if is_down:
            if not win_held:
                win_held = True
                win_vk = vk
                win_down_buffered = True
            return 1

        if is_up:
            if quiz_chord_active:
                quiz_chord_active = False
                win_held = False
                win_down_buffered = False
                win_vk = None
                return 1
            if win_down_buffered:
                replay_win_tap(win_vk or vk)
            win_held = False
            win_down_buffered = False
            win_vk = None
            return 1

    if win_held and is_down:
        if vk == VK_S:
            quiz_chord_active = True
            win_down_buffered = False
            threading.Thread(target=solve, daemon=True).start()
            return 1
        if win_down_buffered:
            replay_win_down(win_vk or VK_LWIN)
            win_down_buffered = False
        return user32.CallNextHookEx(hook_handle, nCode, wParam, lParam)

    if quiz_chord_active and vk == VK_S and is_up:
        return 1

    return user32.CallNextHookEx(hook_handle, nCode, wParam, lParam)


def install_hook():
    global hook_handle, hook_proc_ref

    hook_proc_ref = LowLevelKeyboardProc(hook_callback)

    # Critical fix: correct pointer-sized HMODULE.
    hmodule = kernel32.GetModuleHandleW(None)
    if not hmodule:
        err = ctypes.get_last_error()
        raise OSError(err, f"GetModuleHandleW failed, WinError={err}")

    ctypes.set_last_error(0)
    hook_handle = user32.SetWindowsHookExW(
        WH_KEYBOARD_LL,
        hook_proc_ref,
        hmodule,
        0,
    )

    if not hook_handle:
        err = ctypes.get_last_error()
        raise OSError(err, f"SetWindowsHookExW failed, WinError={err}")

    return hook_handle


def message_loop():
    msg = wintypes.MSG()
    while True:
        result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
        if result == 0:
            break
        if result == -1:
            err = ctypes.get_last_error()
            raise OSError(err, f"GetMessageW failed, WinError={err}")
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))


def main():
    global selected_model
    try:
        log("=" * 58)
        log("QuizShot ChatGPT v3.2.2 - CLIPBOARD HISTORY MODE")
        creds = ensure_credentials()
        if token_needs_refresh(creds):
            creds = refresh_credentials(creds)
        selected_model = select_model(creds["access_token"])
        log("ChatGPT connected" + (f": {creds.get('email')}" if creds.get("email") else ""))
        log(f"Model: {selected_model}")

        try:
            SESSION.get(
                MODELS_URL,
                headers={"Authorization": f"Bearer {creds['access_token']}"},
                timeout=5,
            )
            log("HTTP connection warmed.")
        except Exception:
            pass

        install_hook()
        log("QuizShot Win+S hook ACTIVE.")
        log("Other Windows shortcuts remain available.")
        log("Ready.")
        log("Workflow: Win+S -> beep -> Win+V")
        message_loop()

    except Exception as e:
        log(f"FATAL ERROR: {e}")
        error_beep()
        try:
            input("Press Enter to close...")
        except Exception:
            pass
    finally:
        if hook_handle:
            try:
                user32.UnhookWindowsHookEx(hook_handle)
            except Exception:
                pass


if __name__ == "__main__":
    main()
