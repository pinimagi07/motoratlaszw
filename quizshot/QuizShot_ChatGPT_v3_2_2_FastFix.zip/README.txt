QUIZSHOT CHATGPT v3.2.2 — FAST/SHORTCUT FIX
===============================================

Fixes the two errors visible in v3.2.1:

1) "ChatGPT returned no answer text."
   - Uses reasoning.effort = none for GPT-5.6/6 Luna-style models.
   - Raises max_output_tokens from 24 to 96.
   - The prompt still requests ONLY A/B/C/D for normal multiple-choice questions.

2) "SendInput failed last_error=87"
   - Corrects the native 64-bit Windows INPUT structure.
   - Win+V, Win+E and other Windows shortcuts can be replayed correctly.

UPDATE
======
1. Close the old QuizShot window.
2. Extract this ZIP.
3. Open python-helper.
4. Run install.bat once.
5. Right-click start_debug.bat -> Run as administrator.
6. Wait for:
     ChatGPT connected
     Model: ...
     QuizShot Win+S hook ACTIVE.
     Other Windows shortcuts remain available.
     Ready.

TEST
====
Open one quiz question.
Press Win+S.
Wait for ONE high beep.
Press Win+V.

For a normal multiple-choice question, the newest Clipboard History item should
be only A, B, C or D.

After the debug version works, use start_silent.vbs for background use.

Existing ChatGPT credentials under %LOCALAPPDATA%\QuizShotGPT are reused.
