QUIZSHOT CHATGPT v3.2.3 — NEW PC SETUP
=========================================

This package contains the working v3.2.2 Fast Fix plus a one-click Python setup.

ON A PC THAT DOES NOT HAVE PYTHON
=================================
1. Extract this ZIP.
2. Open the python-helper folder.
3. Double-click:

       SETUP_NEW_PC.bat

That automatically:
- checks whether Python is already installed
- installs official Python 3.14 if Python is missing
- installs pip
- installs all QuizShot packages from requirements.txt

It first tries Windows Package Manager (winget). If winget is unavailable,
it downloads the official Python 3.14.8 64-bit installer directly from
python.org and installs it for the current Windows user.

WHEN SETUP FINISHES
===================
Right-click:

       start_debug.bat

Choose:

       Run as administrator

Wait for:

       ChatGPT connected
       Model: ...
       QuizShot Win+S hook ACTIVE.
       Ready.

NORMAL USE
==========
Question visible -> Win+S -> one high beep -> Win+V

EXTRA FILE
==========
CHECK_PYTHON.bat

Double-click it if you only want to check whether Python is installed.

REQUIREMENTS
============
- 64-bit Windows 10 or Windows 11
- Internet connection during first setup
- ChatGPT account
- Clipboard History enabled for Win+V

This setup does NOT install Windows itself. It is for Windows computers that
are missing Python.
