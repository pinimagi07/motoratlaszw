@echo off
cd /d "%~dp0"
title QuizShot New PC Setup
call INSTALL_PYTHON_AND_QUIZSHOT.bat
