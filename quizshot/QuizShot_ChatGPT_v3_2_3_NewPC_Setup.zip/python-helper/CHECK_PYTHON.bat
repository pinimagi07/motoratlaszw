@echo off
title QuizShot Python Check
echo.
echo Checking this computer...
echo.

py -3 --version
if %errorlevel%==0 goto :FOUND

python --version
if %errorlevel%==0 goto :FOUND

echo Python is NOT installed.
echo Run SETUP_NEW_PC.bat.
goto :END

:FOUND
echo.
echo Python is installed.

:END
echo.
pause
