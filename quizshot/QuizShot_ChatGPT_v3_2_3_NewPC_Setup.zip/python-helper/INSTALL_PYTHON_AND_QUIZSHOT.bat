@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title QuizShot - Install Python

echo ============================================================
echo QuizShot - Python Installer
echo ============================================================
echo.

REM ------------------------------------------------------------
REM 1. If Python already exists, do not reinstall it.
REM ------------------------------------------------------------
py -3 --version >nul 2>&1
if %errorlevel%==0 (
    echo Python is already installed.
    py -3 --version
    goto :INSTALL_PACKAGES_WITH_PY
)

python --version >nul 2>&1
if %errorlevel%==0 (
    echo Python is already installed.
    python --version
    goto :INSTALL_PACKAGES_WITH_PYTHON
)

echo Python was not found.
echo Installing official Python 3.14.8 64-bit...
echo.

REM ------------------------------------------------------------
REM 2. First try winget if this Windows PC has it.
REM ------------------------------------------------------------
where winget >nul 2>&1
if %errorlevel%==0 (
    echo Trying Windows Package Manager...
    winget install --id Python.Python.3.14 -e --scope user --silent ^
      --accept-package-agreements --accept-source-agreements

    if %errorlevel%==0 (
        echo.
        echo Python installation completed through winget.
        goto :FIND_NEW_PYTHON
    )
)

REM ------------------------------------------------------------
REM 3. Fallback: download official installer directly from
REM    python.org and install silently for this Windows user.
REM ------------------------------------------------------------
echo.
echo Winget was unavailable or did not complete the install.
echo Downloading directly from python.org...
echo.

set "PYVER=3.14.8"
set "PYINSTALLER=%TEMP%\python-%PYVER%-amd64.exe"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%PYURL%' -OutFile '%PYINSTALLER%'"

if not exist "%PYINSTALLER%" (
    echo.
    echo ERROR: Python installer could not be downloaded.
    echo Check the internet connection and try again.
    pause
    exit /b 1
)

echo Installing Python...
start /wait "" "%PYINSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 Include_test=0

if not %errorlevel%==0 (
    echo.
    echo ERROR: Python installer returned error %errorlevel%.
    pause
    exit /b 1
)

del /q "%PYINSTALLER%" >nul 2>&1

:FIND_NEW_PYTHON
echo.
echo Locating Python...

if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    set "QUIZPY=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    goto :INSTALL_PACKAGES_DIRECT
)

if exist "%ProgramFiles%\Python314\python.exe" (
    set "QUIZPY=%ProgramFiles%\Python314\python.exe"
    goto :INSTALL_PACKAGES_DIRECT
)

REM Refresh through the launcher if available.
py -3 --version >nul 2>&1
if %errorlevel%==0 goto :INSTALL_PACKAGES_WITH_PY

python --version >nul 2>&1
if %errorlevel%==0 goto :INSTALL_PACKAGES_WITH_PYTHON

echo.
echo ERROR: Python appears to have installed, but QuizShot cannot find it.
echo Restart Windows and run this installer again.
pause
exit /b 1

:INSTALL_PACKAGES_WITH_PY
echo.
echo Installing QuizShot packages...
py -3 -m pip install --upgrade pip
py -3 -m pip install -r requirements.txt
if not %errorlevel%==0 goto :PACKAGE_ERROR
goto :DONE

:INSTALL_PACKAGES_WITH_PYTHON
echo.
echo Installing QuizShot packages...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not %errorlevel%==0 goto :PACKAGE_ERROR
goto :DONE

:INSTALL_PACKAGES_DIRECT
echo.
echo Python found at:
echo %QUIZPY%
echo.
echo Installing QuizShot packages...
"%QUIZPY%" -m pip install --upgrade pip
"%QUIZPY%" -m pip install -r requirements.txt
if not %errorlevel%==0 goto :PACKAGE_ERROR
goto :DONE

:PACKAGE_ERROR
echo.
echo ERROR: Python is installed, but one or more QuizShot packages failed.
echo Check the internet connection and run this installer again.
pause
exit /b 1

:DONE
echo.
echo ============================================================
echo SETUP COMPLETE
echo ============================================================
echo Python and all QuizShot packages are ready.
echo.
echo Next:
echo 1. Right-click start_debug.bat
echo 2. Choose Run as administrator
echo 3. Wait until QuizShot says Ready
echo.
echo Normal use:
echo Question ^> Win+S ^> high beep ^> Win+V
echo.
pause
exit /b 0
